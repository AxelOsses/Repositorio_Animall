package com.animall.api_tienda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiTiendaApplicationTests {

	@Test
	void contextLoads() {
	}

}
