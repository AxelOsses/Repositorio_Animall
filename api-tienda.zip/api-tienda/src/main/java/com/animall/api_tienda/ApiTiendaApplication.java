package com.animall.api_tienda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiTiendaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiTiendaApplication.class, args);
	}

}
